Run program

uvicorn main:app --reload

****************************************
main คือชื่อไฟล์ที่จะรัน เช่น ไฟล์ชื่อ xd.py จะเป็น uvicorn xd:app --reload

--reload เวลา save งาน program จะ auto reload ไม่ต้องรันใหม่